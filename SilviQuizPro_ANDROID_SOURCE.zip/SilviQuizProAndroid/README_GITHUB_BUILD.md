# SilviQuiz Pro GitHub Build

Updated classroom source: polished forest-themed UI, fixed student JOIN flow, server-authoritative scoring, exam manager API, corrected 60-item Wood ID answer mapping, and Android API 36 build target.

GitHub Actions: `clean assembleDebug`

The workflow installs Android API 36 / Build Tools 36.0.0.
