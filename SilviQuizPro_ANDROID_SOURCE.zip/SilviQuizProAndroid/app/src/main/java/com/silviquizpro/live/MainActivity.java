package com.silviquizpro.live;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebViewClient;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    WebView web; HttpServer server;
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        try {
            web=new WebView(this);
            WebSettings s=web.getSettings();
            s.setJavaScriptEnabled(true);
            s.setDomStorageEnabled(true);
            s.setAllowFileAccess(true);
            s.setAllowContentAccess(true);
            web.setWebViewClient(new WebViewClient());
            setContentView(web);
            web.loadDataWithBaseURL(null,"<html><body style='font-family:sans-serif;padding:24px'><h2>SilviQuiz Pro</h2><p>Starting local classroom server...</p></body></html>","text/html","UTF-8",null);
            server=new HttpServer(8787);
            server.start();
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                try { if(web!=null) web.loadUrl("http://127.0.0.1:8787/teacher.html"); }
                catch(Throwable t){ showStartupError(t); }
            },1000);
        } catch(Throwable t){ showStartupError(t); }
    }
    void showStartupError(Throwable t){
        try {
            if(web!=null){ String msg=String.valueOf(t.getClass().getSimpleName()+": "+t.getMessage()).replace("&","&amp;").replace("<","&lt;").replace(">","&gt;");
                web.loadDataWithBaseURL(null,"<html><body style='font-family:sans-serif;padding:24px'><h2>SilviQuiz Pro Startup Error</h2><p>"+msg+"</p><p>Close and reopen the app.</p></body></html>","text/html","UTF-8",null); }
        } catch(Throwable ignored) {}
    }
    @Override protected void onDestroy(){if(server!=null)server.stop();super.onDestroy();}

    static class Student {String id,name; int score=0; Student(String i,String n){id=i;name=n;}}
    class HttpServer {
        int port; volatile boolean run=true; ServerSocket ss; Thread serverThread; ExecutorService pool=Executors.newCachedThreadPool();
        int question=0; boolean active=false,revealed=false; long endAt=0; String examId="";
        final ArrayList<Student> students=new ArrayList<>(); final HashSet<String> answered=new HashSet<>(); final Object lock=new Object();
        JSONArray exams=new JSONArray();
        File store(){return new File(getFilesDir(),"examsets.json");}
        HttpServer(int p){port=p; loadExams();}
        void start(){
            run=true;
            serverThread=new Thread(() -> {
                try {
                    ss=new ServerSocket(port);
                    while(run){
                        final Socket s=ss.accept();
                        pool.execute(() -> handle(s));
                    }
                } catch(Exception ignored) {
                }
            }, "SilviQuizPro-HttpServer");
            serverThread.start();
        }
        void stop(){
            run=false;
            try{if(ss!=null)ss.close();}catch(Exception ignored){}
            pool.shutdownNow();
        }
        void loadExams(){
            JSONArray fallback=new JSONArray();
            try {
                JSONArray q=new JSONArray(asset("questions.json"));
                JSONObject e=new JSONObject();
                e.put("id","woodid_midterm_2026");
                e.put("name","Wood Structure & Identification Midterm 2026");
                e.put("questions",q);
                fallback.put(e);
            } catch(Exception ignored) {}
            exams=fallback;
            examId=exams.length()>0?exams.optJSONObject(0).optString("id",""):"";
            // Use the bundled 60-question exam as the safe startup database.
            // Persisted exam sets are loaded only through explicit save/import actions.
            // This avoids startup crashes caused by legacy/corrupt local data.
            try { saveExams(); } catch(Exception ignored) {}
        }
        void saveExams(){try{writeFile(store(),exams.toString());}catch(Exception ignored){}}
        String readFile(File f)throws Exception{ByteArrayOutputStream o=new ByteArrayOutputStream();InputStream in=new FileInputStream(f);byte[] b=new byte[8192];int n;while((n=in.read(b))>0)o.write(b,0,n);in.close();return o.toString("UTF-8");}
        void writeFile(File f,String x)throws Exception{FileOutputStream o=new FileOutputStream(f);o.write(x.getBytes(StandardCharsets.UTF_8));o.close();}
        String asset(String n)throws Exception{InputStream in=getAssets().open(n);ByteArrayOutputStream o=new ByteArrayOutputStream();byte[] b=new byte[8192];int k;while((k=in.read(b))>0)o.write(b,0,k);in.close();return o.toString("UTF-8");}
        JSONArray questions(){synchronized(lock){try{for(int i=0;i<exams.length();i++){JSONObject e=exams.getJSONObject(i);if(e.getString("id").equals(examId))return e.getJSONArray("questions");}}catch(Exception ignored){}return new JSONArray();}}
        JSONObject currentQuestion(){try{JSONArray q=questions();return q.length()>question?q.getJSONObject(question):new JSONObject();}catch(Exception e){return new JSONObject();}}
        String esc(String x){return x.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n").replace("\r","");}
        String state(){synchronized(lock){StringBuilder a=new StringBuilder("[");for(int i=0;i<students.size();i++){Student st=students.get(i);if(i>0)a.append(",");a.append("{\"id\":\"").append(esc(st.id)).append("\",\"name\":\"").append(esc(st.name)).append("\",\"score\":").append(st.score).append("}");}a.append("]");long left=active?Math.max(0,(endAt-System.currentTimeMillis())/1000):0;String en="";try{for(int i=0;i<exams.length();i++){JSONObject e=exams.getJSONObject(i);if(e.getString("id").equals(examId)){en=e.optString("name","");break;}}}catch(Exception ignored){}return "{\"examId\":\""+esc(examId)+"\",\"examName\":\""+esc(en)+"\",\"total\":"+questions().length()+",\"question\":"+question+",\"active\":"+active+",\"revealed\":"+revealed+",\"endAt\":"+endAt+",\"secondsLeft\":"+left+",\"students\":"+a+"}";}}
        void send(Socket s,int code,String type,String body)throws Exception{byte[] d=body.getBytes(StandardCharsets.UTF_8);String h="HTTP/1.1 "+code+" OK\r\nContent-Type: "+type+"\r\nAccess-Control-Allow-Origin: *\r\nContent-Length: "+d.length+"\r\nConnection: close\r\n\r\n";s.getOutputStream().write(h.getBytes(StandardCharsets.UTF_8));s.getOutputStream().write(d);}
        Map<String,String> params(String p){Map<String,String>m=new HashMap<>();int q=p.indexOf('?');if(q<0)return m;for(String z:p.substring(q+1).split("&")){String[]a=z.split("=",2);if(a.length==2)m.put(a[0],URLDecoder.decode(a[1],StandardCharsets.UTF_8));}return m;}
        String body(BufferedReader r,int len)throws Exception{char[]c=new char[len];int n=0;while(n<len){int k=r.read(c,n,len-n);if(k<0)break;n+=k;}return new String(c,0,n);}
        int contentLength(String headers){try{for(String x:headers.split("\\r?\\n"))if(x.toLowerCase().startsWith("content-length:"))return Integer.parseInt(x.substring(x.indexOf(':')+1).trim());}catch(Exception ignored){}return 0;}
        void sendError(Socket s,int code,String msg){try{send(s,code,"application/json; charset=utf-8",new JSONObject().put("ok",false).put("error",msg).toString());}catch(Exception ignored){}}
        void handle(Socket s){
            try(s){
                InputStream in=s.getInputStream();
                ByteArrayOutputStream hb=new ByteArrayOutputStream();
                int prev=-1,cur;
                while((cur=in.read())!=-1){hb.write(cur);if(prev=='\r'&&cur=='\n'){
                    byte[] a=hb.toByteArray();int n=a.length;
                    if(n>=4&&a[n-4]=='\r'&&a[n-3]=='\n'&&a[n-2]=='\r'&&a[n-1]=='\n')break;
                }prev=cur;if(hb.size()>65536)throw new IOException("Request headers too large");}
                String headers=new String(hb.toByteArray(),StandardCharsets.ISO_8859_1);
                String[] lines=headers.split("\\r\\n");
                if(lines.length==0)return;
                String[] first=lines[0].split(" ",3);if(first.length<2)return;
                String path=first[1];
                int len=0;
                for(int i=1;i<lines.length;i++){String h=lines[i];int c=h.indexOf(':');if(c>0&&h.substring(0,c).trim().equalsIgnoreCase("Content-Length")){len=Integer.parseInt(h.substring(c+1).trim());break;}}
                byte[] bodyBytes=new byte[len];int got=0;while(got<len){int k=in.read(bodyBytes,got,len-got);if(k<0)break;got+=k;}
                String bd=new String(bodyBytes,0,got,StandardCharsets.UTF_8);

                if(path.startsWith("/api/state")){send(s,200,"application/json",state());return;}
                if(path.startsWith("/api/exam?id=")){Map<String,String>p=params(path);String id=p.get("id");synchronized(lock){for(int i=0;i<exams.length();i++)if(exams.getJSONObject(i).getString("id").equals(id)){send(s,200,"application/json",exams.getJSONObject(i).toString());return;}}sendError(s,404,"Exam not found");return;}
                if(path.startsWith("/api/exams")){StringBuilder x=new StringBuilder("[");synchronized(lock){for(int i=0;i<exams.length();i++){if(i>0)x.append(',');JSONObject e=exams.getJSONObject(i);x.append("{\"id\":\"").append(esc(e.getString("id"))).append("\",\"name\":\"").append(esc(e.getString("name"))).append("\",\"count\":").append(e.getJSONArray("questions").length()).append("}");}}x.append(']');send(s,200,"application/json",x.toString());return;}
                if(path.startsWith("/api/exam/select")){Map<String,String>p=params(path);synchronized(lock){String id=p.get("id");for(int i=0;i<exams.length();i++)if(exams.getJSONObject(i).getString("id").equals(id)){examId=id;question=0;active=false;revealed=false;students.clear();answered.clear();break;}}send(s,200,"application/json","{\"ok\":true}");return;}
                if(path.startsWith("/api/exam/save")){
                    JSONObject e=new JSONObject(bd);JSONArray q=e.optJSONArray("questions");if(q==null)throw new JSONException("Missing questions array");
                    if(e.optString("id","").trim().isEmpty())throw new JSONException("Missing exam id");
                    if(e.optString("name","").trim().isEmpty())e.put("name","Untitled Exam");
                    synchronized(lock){String id=e.getString("id");boolean replaced=false;for(int i=0;i<exams.length();i++)if(exams.getJSONObject(i).getString("id").equals(id)){exams.put(i,e);replaced=true;break;}if(!replaced)exams.put(e);examId=id;saveExams();question=0;active=false;revealed=false;students.clear();answered.clear();}
                    send(s,200,"application/json","{\"ok\":true,\"count\":"+q.length()+"}");return;
                }
                if(path.startsWith("/api/exam/delete")){Map<String,String>p=params(path);synchronized(lock){String id=p.get("id");for(int i=exams.length()-1;i>=0;i--)if(exams.getJSONObject(i).getString("id").equals(id))exams.remove(i);if(exams.length()==0){JSONObject e=new JSONObject();e.put("id","new_exam");e.put("name","New Exam");e.put("questions",new JSONArray());exams.put(e);}examId=exams.getJSONObject(0).getString("id");saveExams();question=0;active=false;students.clear();answered.clear();}send(s,200,"application/json","{\"ok\":true}");return;}
                if(path.startsWith("/api/register")){Map<String,String>p=params(path);String name=p.getOrDefault("name","").trim();if(name.isEmpty()||name.length()>60){sendError(s,400,"Please enter a valid name");return;}String id=UUID.randomUUID().toString();synchronized(lock){boolean exists=false;for(Student st:students)if(st.name.equalsIgnoreCase(name))exists=true;if(exists){sendError(s,409,"Name already joined");return;}students.add(new Student(id,name));}send(s,200,"application/json","{\"id\":\""+esc(id)+"\"}");return;}
                if(path.startsWith("/api/start")){synchronized(lock){active=true;revealed=false;endAt=System.currentTimeMillis()+30000;}send(s,200,"application/json","{\"ok\":true}");return;}
                if(path.startsWith("/api/next")){synchronized(lock){if(question<questions().length()-1)question++;active=true;revealed=false;endAt=System.currentTimeMillis()+30000;}send(s,200,"application/json","{\"ok\":true}");return;}
                if(path.startsWith("/api/reveal")){synchronized(lock){active=false;revealed=true;}send(s,200,"application/json","{\"ok\":true}");return;}
                if(path.startsWith("/api/reset")){synchronized(lock){question=0;active=false;revealed=false;students.clear();answered.clear();}send(s,200,"application/json","{\"ok\":true}");return;}
                if(path.startsWith("/api/answer")){Map<String,String>p=params(path);String id=p.get("id"),a=p.get("a");synchronized(lock){String key=id+":"+question;if(active&&!revealed&&!answered.contains(key)&&id!=null&&a!=null&&("A".equalsIgnoreCase(a)||"B".equalsIgnoreCase(a)||"C".equalsIgnoreCase(a)||"D".equalsIgnoreCase(a))){JSONObject cq=currentQuestion();String correct=cq.optString("correct","");if(correct.isEmpty()){JSONObject f=cq.optJSONObject("feedback");if(f!=null)for(String l:new String[]{"A","B","C","D"})if(f.optJSONObject(l)!=null&&"CORRECT".equals(f.optJSONObject(l).optString("status")))correct=l;}for(Student st:students)if(st.id.equals(id)){if(a.equalsIgnoreCase(correct))st.score++;answered.add(key);break;}}}send(s,200,"application/json","{\"ok\":true}");return;}
                if(path.equals("/")||path.equals("/teacher.html")||path.equals("/student.html")||path.equals("/display.html")||path.equals("/manager.html")){String file=path.equals("/")?"teacher.html":path.substring(1);send(s,200,"text/html; charset=utf-8",asset(file));return;}
                if(path.equals("/questions.json")){JSONArray qq=questions();if(qq.length()==0){try{qq=new JSONArray(asset("questions.json"));}catch(Exception ignored){}}send(s,200,"application/json; charset=utf-8",qq.toString());return;}
                send(s,404,"text/plain","Not found");
            }catch(Exception e){sendError(s,500,e.getMessage()==null?"Server error":e.getMessage());}
        }
    }
}
