SilviQuiz Pro - Question Bank / CSV Import Fix

This build fixes the Question Bank CSV import path.

Teacher > Question Bank / Exam Manager now supports:
1. Choose a CSV file directly from the Android tablet.
2. Or paste CSV text into the box.
3. Validate required columns: Question,A,B,C,D,Correct,Rationale.
4. Validate each row and Correct value (A/B/C/D).
5. Import as a new exam set and show the imported question count.
6. Display server-side import errors instead of silently failing.

The local HTTP server now reads POST bodies as UTF-8 bytes using Content-Length, which fixes failures with CSV/JSON containing Filipino punctuation, em dashes, accented characters, and other non-ASCII text.

The included seed exam remains:
Wood Structure & Identification Midterm 2026 (60)

The included CSV is:
docs/Wood_ID_Midterm_2026_60Q_CORRECTED.csv
